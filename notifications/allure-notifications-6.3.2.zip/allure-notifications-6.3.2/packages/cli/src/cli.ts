/**
 * Programmatic CLI entry — used by bin and tests.
 */

import { createRequire } from "node:module";

import { helpText, parseArgs } from "./parse.js";
import { send } from "./send.js";
import { suggest } from "./suggest.js";

export const PACKAGE = "allure-notifications";
export const PHASE = 3;

/** Keep in sync with packages/cli/package.json (published npm version). */
const require = createRequire(import.meta.url);
export const VERSION = (
  require("../../package.json") as { version: string }
).version;

export type RunCliResult = {
  exitCode: number;
  stdout: string;
  stderr: string;
};

function modeLabel(result: {
  dryRun: boolean;
  mock: boolean;
  live: boolean;
}): string {
  if (result.live) {
    return "live";
  }
  if (result.mock) {
    return "mock";
  }
  return "dry-run";
}

/**
 * Run CLI against argv (without node/script). Does not call process.exit.
 */
export async function runCli(argv: string[]): Promise<RunCliResult> {
  const args = parseArgs(argv);

  if (args.command === "help") {
    return {
      exitCode: args.errors.length > 0 ? 1 : 0,
      stdout: helpText(),
      stderr: args.errors.length ? args.errors.join("\n") + "\n" : "",
    };
  }

  if (args.command === "version") {
    return { exitCode: 0, stdout: `${VERSION}\n`, stderr: "" };
  }

  if (args.errors.length > 0) {
    return {
      exitCode: 1,
      stdout: "",
      stderr: args.errors.join("\n") + "\n" + helpText(),
    };
  }

  try {
    if (args.command === "suggest") {
      const result = await suggest({
        resultsFolder: args.resultsFolder!,
        profile: args.profile,
        configPath: args.configPath,
        out: args.out,
        signalsOnly: args.signalsOnly,
      });
      return {
        exitCode: 0,
        stdout: result.outPath ? "" : result.json,
        stderr: result.warnings.map((warning) => `warning: ${warning}\n`).join(""),
      };
    }
    const result = await send({
      configPath: args.configPath!,
      dryRun: args.dryRun,
      mock: args.mock,
      live: args.live,
      out: args.out,
      overrides: {
        allureFolder: args.allureFolder,
        allureResultsFolder: args.allureResultsFolder,
        project: args.project,
        reportUrl: args.reportUrl,
        dashboardUrl: args.dashboardUrl,
        testopsUrl: args.testopsUrl,
        buildUrl: args.buildUrl,
      },
    });

    const lines: string[] = [
      `allure-notifications ${VERSION}`,
      `config: ${result.configPath}`,
      `collage: ${result.png.byteLength} bytes` +
        (result.pngPath ? ` → ${result.pngPath}` : ""),
      `mode: ${modeLabel(result)}`,
    ];
    for (const d of result.deliveries) {
      lines.push(`  [${d.status}] ${d.messenger}: ${d.detail}`);
    }
    lines.push("ok");

    return { exitCode: 0, stdout: lines.join("\n") + "\n", stderr: "" };
  } catch (err) {
    return { exitCode: 1, stdout: "", stderr: `error: ${formatCliError(err)}\n` };
  }
}

/** Exported for unit coverage of non-Error throw formatting. */
export function formatCliError(err: unknown): string {
  return err instanceof Error ? err.message : String(err);
}
